import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, decimal } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * メーカーマスターテーブル
 * 美容医療メーカーの情報を管理
 */
export const manufacturers = mysqlTable("manufacturers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  corporateNumber: varchar("corporateNumber", { length: 20 }).unique(),
  aliases: text("aliases"), // JSON配列として保存（カンマ区切りの別名）
  marginRate: decimal("marginRate", { precision: 5, scale: 2 }).default("5.00").notNull(), // マージン率（%）、デフォルト5%
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Manufacturer = typeof manufacturers.$inferSelect;
export type InsertManufacturer = typeof manufacturers.$inferInsert;

/**
 * 請求書処理バッチテーブル
 * 1回の処理セッション（複数請求書のアップロード）を管理
 */
export const invoiceBatches = mysqlTable("invoiceBatches", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  year: int("year").notNull(),
  month: int("month").notNull(),
  status: mysqlEnum("status", ["processing", "completed", "failed"]).default("processing").notNull(),
  totalFiles: int("totalFiles").notNull(),
  successCount: int("successCount").default(0).notNull(),
  failedCount: int("failedCount").default(0).notNull(),
  excelFileKey: varchar("excelFileKey", { length: 512 }),
  excelFileUrl: varchar("excelFileUrl", { length: 1024 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type InvoiceBatch = typeof invoiceBatches.$inferSelect;
export type InsertInvoiceBatch = typeof invoiceBatches.$inferInsert;

/**
 * 請求書データテーブル
 * 抽出された請求書情報を保存
 */
export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  batchId: int("batchId").notNull(),
  manufacturerId: int("manufacturerId"),
  manufacturerName: varchar("manufacturerName", { length: 255 }),
  invoiceNumber: varchar("invoiceNumber", { length: 100 }),
  invoiceDate: timestamp("invoiceDate"),
  hasReducedTax: boolean("hasReducedTax").default(false).notNull(),
  
  // 請求書記載金額
  subtotalExcludingTax: int("subtotalExcludingTax").notNull(), // 税抜合計（円単位）
  subtotalIncludingTax: int("subtotalIncludingTax").notNull(), // 税込合計（円単位）
  
  // 税率（0.10 or 0.08）
  taxRate: varchar("taxRate", { length: 10 }).notNull(),
  
  // 税率別内訳（JSON形式で保存）
  taxRateBreakdowns: text("taxRateBreakdowns"), // JSON: [{ taxRate, subtotalExcludingTax, subtotalIncludingTax }]
  
  // 元ファイル情報
  originalFileKey: varchar("originalFileKey", { length: 512 }).notNull(),
  originalFileUrl: varchar("originalFileUrl", { length: 1024 }).notNull(),
  originalFileName: varchar("originalFileName", { length: 255 }).notNull(),
  
  // 抽出されたテキスト（デバッグ用）
  extractedText: text("extractedText"),
  
  // ステータス
  status: mysqlEnum("status", ["pending", "confirmed", "failed"]).default("pending").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;
