CREATE TABLE `invoiceBatches` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`year` int NOT NULL,
	`month` int NOT NULL,
	`status` enum('processing','completed','failed') NOT NULL DEFAULT 'processing',
	`totalFiles` int NOT NULL,
	`successCount` int NOT NULL DEFAULT 0,
	`failedCount` int NOT NULL DEFAULT 0,
	`excelFileKey` varchar(512),
	`excelFileUrl` varchar(1024),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `invoiceBatches_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `invoices` (
	`id` int AUTO_INCREMENT NOT NULL,
	`batchId` int NOT NULL,
	`manufacturerId` int,
	`manufacturerName` varchar(255),
	`invoiceNumber` varchar(100),
	`invoiceDate` timestamp,
	`hasReducedTax` boolean NOT NULL DEFAULT false,
	`subtotalExcludingTax` int NOT NULL,
	`subtotalIncludingTax` int NOT NULL,
	`taxRate` varchar(10) NOT NULL,
	`originalFileKey` varchar(512) NOT NULL,
	`originalFileUrl` varchar(1024) NOT NULL,
	`originalFileName` varchar(255) NOT NULL,
	`extractedText` text,
	`status` enum('pending','confirmed','failed') NOT NULL DEFAULT 'pending',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `invoices_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `manufacturers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`corporateNumber` varchar(20),
	`aliases` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `manufacturers_id` PRIMARY KEY(`id`),
	CONSTRAINT `manufacturers_corporateNumber_unique` UNIQUE(`corporateNumber`)
);
