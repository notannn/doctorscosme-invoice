import { useState, useCallback, useEffect } from "react";
// import { useAuth } from "@/_core/hooks/useAuth"; // 認証不要のためコメントアウト
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Upload as UploadIcon, FileText, CheckCircle, XCircle, Loader2, Settings, Plus, X, Edit, Trash2 } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface UploadedFile {
  file: File;
  status: "pending" | "processing" | "success" | "error";
  invoiceId?: number;
  manufacturerName?: string;
  confidence?: string;
  hasReducedTax?: boolean;
  error?: string;
}

interface Manufacturer {
  id: number;
  name: string;
  corporateNumber: string | null;
  aliases: string | null;
  marginRate: string;
}

export default function Upload() {
  // const { user, loading: authLoading } = useAuth(); // 認証不要のためコメントアウト
  const [, setLocation] = useLocation();
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [files, setFiles] = useState<UploadedFile[]>([]);
  const [batchId, setBatchId] = useState<number | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [marginRates, setMarginRates] = useState<Record<number, string>>({});
  const [isMarginDialogOpen, setIsMarginDialogOpen] = useState(false);
  const [isAddManufacturerDialogOpen, setIsAddManufacturerDialogOpen] = useState(false);
  const [isEditManufacturerDialogOpen, setIsEditManufacturerDialogOpen] = useState(false);
  const [deleteConfirmManufacturerId, setDeleteConfirmManufacturerId] = useState<number | null>(null);
  const [editingManufacturer, setEditingManufacturer] = useState<Manufacturer | null>(null);
  
  // 新規メーカー追加フォームの状態
  const [newManufacturerName, setNewManufacturerName] = useState("");
  const [newManufacturerCorporateNumber, setNewManufacturerCorporateNumber] = useState("");
  const [newManufacturerAliases, setNewManufacturerAliases] = useState<string[]>([""]);
  const [newManufacturerMarginRate, setNewManufacturerMarginRate] = useState("5.00");

  // 編集フォームの状態
  const [editManufacturerName, setEditManufacturerName] = useState("");
  const [editManufacturerCorporateNumber, setEditManufacturerCorporateNumber] = useState("");
  const [editManufacturerAliases, setEditManufacturerAliases] = useState<string[]>([""]);
  const [editManufacturerMarginRate, setEditManufacturerMarginRate] = useState("5.00");

  const createBatchMutation = trpc.invoices.createBatch.useMutation();
  const uploadMutation = trpc.invoices.uploadAndProcess.useMutation();
  const { data: manufacturers, refetch: refetchManufacturers } = trpc.manufacturers.list.useQuery();
  const updateMarginRateMutation = trpc.manufacturers.updateMarginRate.useMutation();
  const createManufacturerMutation = trpc.manufacturers.create.useMutation();
  const updateManufacturerMutation = trpc.manufacturers.update.useMutation();
  const deleteManufacturerMutation = trpc.manufacturers.delete.useMutation();

  // メーカーマスターデータが読み込まれたら、初期値を設定
  useEffect(() => {
    if (manufacturers) {
      const initialRates: Record<number, string> = {};
      manufacturers.forEach((m) => {
        initialRates[m.id] = m.marginRate || "5.00";
      });
      setMarginRates(initialRates);
    }
  }, [manufacturers]);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const uploadedFiles: UploadedFile[] = selectedFiles.map((file) => ({
      file,
      status: "pending",
    }));
    setFiles(uploadedFiles);
  }, []);

  const handleMarginRateChange = (manufacturerId: number, value: string) => {
    setMarginRates((prev) => ({
      ...prev,
      [manufacturerId]: value,
    }));
  };

  const saveMarginRates = async () => {
    try {
      for (const [id, rate] of Object.entries(marginRates)) {
        await updateMarginRateMutation.mutateAsync({
          id: Number(id),
          marginRate: rate,
        });
      }
      toast.success("マージン率を保存しました");
      setIsMarginDialogOpen(false);
      refetchManufacturers();
    } catch (error) {
      toast.error("マージン率の保存に失敗しました");
      console.error(error);
    }
  };

  const addAliasField = () => {
    setNewManufacturerAliases([...newManufacturerAliases, ""]);
  };

  const removeAliasField = (index: number) => {
    setNewManufacturerAliases(newManufacturerAliases.filter((_, i) => i !== index));
  };

  const updateAlias = (index: number, value: string) => {
    const updated = [...newManufacturerAliases];
    updated[index] = value;
    setNewManufacturerAliases(updated);
  };

  const addEditAliasField = () => {
    setEditManufacturerAliases([...editManufacturerAliases, ""]);
  };

  const removeEditAliasField = (index: number) => {
    setEditManufacturerAliases(editManufacturerAliases.filter((_, i) => i !== index));
  };

  const updateEditAlias = (index: number, value: string) => {
    const updated = [...editManufacturerAliases];
    updated[index] = value;
    setEditManufacturerAliases(updated);
  };

  const handleCreateManufacturer = async () => {
    if (!newManufacturerName.trim()) {
      toast.error("メーカー名を入力してください");
      return;
    }

    try {
      const filteredAliases = newManufacturerAliases.filter((alias) => alias.trim() !== "");
      
      await createManufacturerMutation.mutateAsync({
        name: newManufacturerName,
        corporateNumber: newManufacturerCorporateNumber.trim() || null,
        aliases: filteredAliases,
        marginRate: newManufacturerMarginRate,
      });

      toast.success("メーカーを追加しました");
      
      // フォームをリセット
      setNewManufacturerName("");
      setNewManufacturerCorporateNumber("");
      setNewManufacturerAliases([""]);
      setNewManufacturerMarginRate("5.00");
      setIsAddManufacturerDialogOpen(false);
      
      // メーカーリストを再取得
      refetchManufacturers();
    } catch (error) {
      toast.error("メーカーの追加に失敗しました");
      console.error(error);
    }
  };

  const handleEditManufacturer = (manufacturer: Manufacturer) => {
    setEditingManufacturer(manufacturer);
    setEditManufacturerName(manufacturer.name);
    setEditManufacturerCorporateNumber(manufacturer.corporateNumber || "");
    
    try {
      const aliases = manufacturer.aliases ? JSON.parse(manufacturer.aliases) : [];
      setEditManufacturerAliases(Array.isArray(aliases) && aliases.length > 0 ? aliases : [""]);
    } catch {
      setEditManufacturerAliases([""]);
    }
    
    setEditManufacturerMarginRate(manufacturer.marginRate || "5.00");
    setIsEditManufacturerDialogOpen(true);
  };

  const handleUpdateManufacturer = async () => {
    if (!editingManufacturer || !editManufacturerName.trim()) {
      toast.error("メーカー名を入力してください");
      return;
    }

    try {
      const filteredAliases = editManufacturerAliases.filter((alias) => alias.trim() !== "");
      
      await updateManufacturerMutation.mutateAsync({
        id: editingManufacturer.id,
        name: editManufacturerName,
        corporateNumber: editManufacturerCorporateNumber.trim() || null,
        aliases: filteredAliases,
        marginRate: editManufacturerMarginRate,
      });

      toast.success("メーカー情報を更新しました");
      setIsEditManufacturerDialogOpen(false);
      setEditingManufacturer(null);
      refetchManufacturers();
    } catch (error) {
      toast.error("メーカー情報の更新に失敗しました");
      console.error(error);
    }
  };

  const handleDeleteManufacturer = async (id: number) => {
    try {
      await deleteManufacturerMutation.mutateAsync({ id });
      toast.success("メーカーを削除しました");
      setDeleteConfirmManufacturerId(null);
      refetchManufacturers();
    } catch (error) {
      toast.error("メーカーの削除に失敗しました");
      console.error(error);
    }
  };

  const processFiles = async () => {
    if (files.length === 0) {
      toast.error("ファイルを選択してください");
      return;
    }

    setIsProcessing(true);

    try {
      // バッチを作成
      const { batchId: newBatchId } = await createBatchMutation.mutateAsync({
        year,
        month,
        totalFiles: files.length,
      });

      setBatchId(newBatchId);

      // 各ファイルを処理
      for (let i = 0; i < files.length; i++) {
        const fileData = files[i];
        if (!fileData) continue;

        setFiles((prev) =>
          prev.map((f, idx) =>
            idx === i ? { ...f, status: "processing" as const } : f
          )
        );

        try {
          // ファイルをBase64に変換
          const base64Data = await fileToBase64(fileData.file);

          // アップロードと処理
          const result = await uploadMutation.mutateAsync({
            batchId: newBatchId,
            fileName: fileData.file.name,
            fileData: base64Data,
            mimeType: fileData.file.type,
          });

          setFiles((prev) =>
            prev.map((f, idx) =>
              idx === i
                ? {
                    ...f,
                    status: "success" as const,
                    invoiceId: result.invoiceId,
                    manufacturerName: result.manufacturerName,
                    confidence: result.confidence,
                    hasReducedTax: result.hasReducedTax,
                  }
                : f
            )
          );
        } catch (error) {
          setFiles((prev) =>
            prev.map((f, idx) =>
              idx === i
                ? {
                    ...f,
                    status: "error" as const,
                    error: error instanceof Error ? error.message : "不明なエラー",
                  }
                : f
            )
          );
        }
      }

      // 全ファイルの処理が完了したら確認画面へ
      setLocation(`/confirm/${newBatchId}`);
    } catch (error) {
      toast.error("処理中にエラーが発生しました");
      console.error(error);
    } finally {
      setIsProcessing(false);
    }
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const base64 = (reader.result as string).split(",")[1];
        resolve(base64 || "");
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  const successCount = files.filter((f) => f.status === "success").length;
  const errorCount = files.filter((f) => f.status === "error").length;
  const progress = files.length > 0 ? ((successCount + errorCount) / files.length) * 100 : 0;

  // 認証不要のため、ログインチェックを削除

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-6">
      <div className="max-w-4xl mx-auto">
        <Card className="shadow-lg">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl flex items-center gap-2">
                  <UploadIcon className="h-6 w-6" />
                  請求書アップロード
                </CardTitle>
                <CardDescription>
                  PDF または画像形式の請求書をアップロードしてください
                </CardDescription>
              </div>
              <Dialog open={isMarginDialogOpen} onOpenChange={setIsMarginDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Settings className="h-4 w-4 mr-2" />
                    マージン率設定
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <DialogTitle>メーカー別マージン率設定</DialogTitle>
                        <DialogDescription>
                          各メーカーのマージン率（%）を設定してください。デフォルトは5%です。
                        </DialogDescription>
                      </div>
                      <Dialog open={isAddManufacturerDialogOpen} onOpenChange={setIsAddManufacturerDialogOpen}>
                        <DialogTrigger asChild>
                          <Button variant="default" size="sm">
                            <Plus className="h-4 w-4 mr-2" />
                            新規メーカー追加
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle>新規メーカー追加</DialogTitle>
                            <DialogDescription>
                              新しいメーカーの情報を入力してください
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4 mt-4">
                            <div>
                              <Label htmlFor="manufacturer-name">メーカー名 *</Label>
                              <Input
                                id="manufacturer-name"
                                value={newManufacturerName}
                                onChange={(e) => setNewManufacturerName(e.target.value)}
                                placeholder="例: ゼオスキン"
                              />
                            </div>
                            <div>
                              <Label htmlFor="corporate-number">法人番号</Label>
                              <Input
                                id="corporate-number"
                                value={newManufacturerCorporateNumber}
                                onChange={(e) => setNewManufacturerCorporateNumber(e.target.value)}
                                placeholder="例: T8010403029561"
                              />
                              <p className="text-sm text-muted-foreground mt-1">
                                法人番号がない場合は空欄のままにしてください
                              </p>
                            </div>
                            <div>
                              <Label>エイリアス（別名）</Label>
                              <div className="space-y-2 mt-2">
                                {newManufacturerAliases.map((alias, index) => (
                                  <div key={index} className="flex gap-2">
                                    <Input
                                      value={alias}
                                      onChange={(e) => updateAlias(index, e.target.value)}
                                      placeholder={`エイリアス ${index + 1}`}
                                    />
                                    {newManufacturerAliases.length > 1 && (
                                      <Button
                                        variant="outline"
                                        size="icon"
                                        onClick={() => removeAliasField(index)}
                                      >
                                        <X className="h-4 w-4" />
                                      </Button>
                                    )}
                                  </div>
                                ))}
                                <Button
                                  variant="outline"
                                  size="sm"
                                  onClick={addAliasField}
                                  className="w-full"
                                >
                                  <Plus className="h-4 w-4 mr-2" />
                                  エイリアスを追加
                                </Button>
                              </div>
                            </div>
                            <div>
                              <Label htmlFor="margin-rate">マージン率 (%)</Label>
                              <Input
                                id="margin-rate"
                                type="number"
                                step="0.01"
                                min="0"
                                max="100"
                                value={newManufacturerMarginRate}
                                onChange={(e) => setNewManufacturerMarginRate(e.target.value)}
                              />
                            </div>
                            <div className="flex justify-end gap-2 mt-6">
                              <Button
                                variant="outline"
                                onClick={() => setIsAddManufacturerDialogOpen(false)}
                              >
                                キャンセル
                              </Button>
                              <Button onClick={handleCreateManufacturer}>
                                追加
                              </Button>
                            </div>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </DialogHeader>
                  <div className="mt-4">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>メーカー名</TableHead>
                          <TableHead>法人番号</TableHead>
                          <TableHead className="w-32">マージン率 (%)</TableHead>
                          <TableHead className="w-24">操作</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {manufacturers?.map((manufacturer) => (
                          <TableRow key={manufacturer.id}>
                            <TableCell className="font-medium">{manufacturer.name}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {manufacturer.corporateNumber || "-"}
                            </TableCell>
                            <TableCell>
                              <Input
                                type="number"
                                step="0.01"
                                min="0"
                                max="100"
                                value={marginRates[manufacturer.id] || "5.00"}
                                onChange={(e) =>
                                  handleMarginRateChange(manufacturer.id, e.target.value)
                                }
                                className="w-24"
                              />
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-1">
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => handleEditManufacturer(manufacturer)}
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  onClick={() => setDeleteConfirmManufacturerId(manufacturer.id)}
                                >
                                  <Trash2 className="h-4 w-4 text-destructive" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                    <div className="mt-6 flex justify-end gap-2">
                      <Button
                        variant="outline"
                        onClick={() => setIsMarginDialogOpen(false)}
                      >
                        キャンセル
                      </Button>
                      <Button onClick={saveMarginRates}>保存</Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="year">年</Label>
                <Input
                  id="year"
                  type="number"
                  value={year}
                  onChange={(e) => setYear(Number(e.target.value))}
                  disabled={isProcessing}
                />
              </div>
              <div>
                <Label htmlFor="month">月</Label>
                <Input
                  id="month"
                  type="number"
                  min="1"
                  max="12"
                  value={month}
                  onChange={(e) => setMonth(Number(e.target.value))}
                  disabled={isProcessing}
                />
              </div>
            </div>

            <div>
              <Label htmlFor="files">請求書ファイル</Label>
              <Input
                id="files"
                type="file"
                multiple
                accept=".pdf,image/*"
                onChange={handleFileChange}
                disabled={isProcessing}
                className="mt-2"
              />
              <p className="text-sm text-muted-foreground mt-2">
                複数のファイルを選択できます（PDF、画像形式対応）
              </p>
            </div>

            {files.length > 0 && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-semibold">
                    アップロード予定: {files.length}件
                  </h3>
                  {isProcessing && (
                    <div className="flex items-center gap-2">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      <span className="text-sm text-muted-foreground">
                        処理中... ({successCount + errorCount}/{files.length})
                      </span>
                    </div>
                  )}
                </div>

                {isProcessing && (
                  <Progress value={progress} className="w-full" />
                )}

                <div className="space-y-2">
                  {files.map((fileData, index) => (
                    <div
                      key={index}
                      className="flex items-center justify-between p-3 border rounded-lg"
                    >
                      <div className="flex items-center gap-3">
                        <FileText className="h-5 w-5 text-muted-foreground" />
                        <div>
                          <p className="font-medium">{fileData.file.name}</p>
                          {fileData.manufacturerName && (
                            <p className="text-sm text-muted-foreground">
                              メーカー: {fileData.manufacturerName}
                              {fileData.hasReducedTax && " (軽減税率あり)"}
                            </p>
                          )}
                        </div>
                      </div>
                      <div>
                        {fileData.status === "pending" && (
                          <span className="text-sm text-muted-foreground">待機中</span>
                        )}
                        {fileData.status === "processing" && (
                          <Loader2 className="h-5 w-5 animate-spin text-primary" />
                        )}
                        {fileData.status === "success" && (
                          <CheckCircle className="h-5 w-5 text-green-500" />
                        )}
                        {fileData.status === "error" && (
                          <XCircle className="h-5 w-5 text-red-500" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>

                {errorCount > 0 && (
                  <Alert variant="destructive">
                    <AlertDescription>
                      {errorCount}件のファイルの処理に失敗しました
                    </AlertDescription>
                  </Alert>
                )}
              </div>
            )}

            <Button
              onClick={processFiles}
              disabled={files.length === 0 || isProcessing}
              className="w-full"
              size="lg"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  処理中...
                </>
              ) : (
                <>
                  <UploadIcon className="mr-2 h-5 w-5" />
                  処理を開始
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* メーカー編集ダイアログ */}
      <Dialog open={isEditManufacturerDialogOpen} onOpenChange={setIsEditManufacturerDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>メーカー編集</DialogTitle>
            <DialogDescription>
              メーカー情報を編集してください
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div>
              <Label htmlFor="edit-manufacturer-name">メーカー名 *</Label>
              <Input
                id="edit-manufacturer-name"
                value={editManufacturerName}
                onChange={(e) => setEditManufacturerName(e.target.value)}
                placeholder="例: ゼオスキン"
              />
            </div>
            <div>
              <Label htmlFor="edit-corporate-number">法人番号</Label>
              <Input
                id="edit-corporate-number"
                value={editManufacturerCorporateNumber}
                onChange={(e) => setEditManufacturerCorporateNumber(e.target.value)}
                placeholder="例: T8010403029561"
              />
            </div>
            <div>
              <Label>エイリアス（別名）</Label>
              <div className="space-y-2 mt-2">
                {editManufacturerAliases.map((alias, index) => (
                  <div key={index} className="flex gap-2">
                    <Input
                      value={alias}
                      onChange={(e) => updateEditAlias(index, e.target.value)}
                      placeholder={`エイリアス ${index + 1}`}
                    />
                    {editManufacturerAliases.length > 1 && (
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => removeEditAliasField(index)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={addEditAliasField}
                  className="w-full"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  エイリアスを追加
                </Button>
              </div>
            </div>
            <div>
              <Label htmlFor="edit-margin-rate">マージン率 (%)</Label>
              <Input
                id="edit-margin-rate"
                type="number"
                step="0.01"
                min="0"
                max="100"
                value={editManufacturerMarginRate}
                onChange={(e) => setEditManufacturerMarginRate(e.target.value)}
              />
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <Button
                variant="outline"
                onClick={() => setIsEditManufacturerDialogOpen(false)}
              >
                キャンセル
              </Button>
              <Button onClick={handleUpdateManufacturer}>
                更新
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* 削除確認ダイアログ */}
      <AlertDialog open={deleteConfirmManufacturerId !== null} onOpenChange={(open) => !open && setDeleteConfirmManufacturerId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>メーカーを削除しますか？</AlertDialogTitle>
            <AlertDialogDescription>
              この操作は取り消せません。このメーカーに関連する過去の請求書データは残りますが、新規の請求書処理でこのメーカーは選択できなくなります。
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>キャンセル</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteConfirmManufacturerId && handleDeleteManufacturer(deleteConfirmManufacturerId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              削除
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
