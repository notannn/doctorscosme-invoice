import { useState } from "react";
// import { useAuth } from "@/_core/hooks/useAuth"; // 認証不要のためコメントアウト
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Download, Edit, CheckCircle } from "lucide-react";
import { useParams, useLocation } from "wouter";
import { toast } from "sonner";

export default function Confirm() {
  const { batchId } = useParams<{ batchId: string }>();
  const [, setLocation] = useLocation();
  // const { user, loading: authLoading } = useAuth(); // 認証不要のためコメントアウト
  const [editingInvoice, setEditingInvoice] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({
    manufacturerName: "",
    invoiceNumber: "",
    invoiceDate: "",
    subtotalExcludingTax: 0,
    subtotalIncludingTax: 0,
  });

  const { data: invoices, isLoading, refetch } = trpc.invoices.listByBatch.useQuery(
    { batchId: parseInt(batchId || "0") },
    { enabled: !!batchId }
  );

  const updateMutation = trpc.invoices.update.useMutation({
    onSuccess: () => {
      toast.success("更新しました");
      refetch();
      setEditingInvoice(null);
    },
  });

  const completeMutation = trpc.invoices.completeBatch.useMutation({
    onSuccess: (data) => {
      toast.success("Excel生成が完了しました");
      // ダウンロード
      window.open(data.excelUrl, "_blank");
      setLocation("/history");
    },
  });

  const handleEdit = (invoice: any) => {
    setEditingInvoice(invoice.id);
    setEditForm({
      manufacturerName: invoice.manufacturerName || "",
      invoiceNumber: invoice.invoiceNumber || "",
      invoiceDate: invoice.invoiceDate
        ? new Date(invoice.invoiceDate).toISOString().split("T")[0]
        : "",
      subtotalExcludingTax: invoice.subtotalExcludingTax,
      subtotalIncludingTax: invoice.subtotalIncludingTax,
    });
  };

  const handleSave = async () => {
    if (editingInvoice === null) return;

    await updateMutation.mutateAsync({
      id: editingInvoice,
      manufacturerName: editForm.manufacturerName,
      invoiceNumber: editForm.invoiceNumber,
      invoiceDate: editForm.invoiceDate ? new Date(editForm.invoiceDate) : undefined,
      subtotalExcludingTax: editForm.subtotalExcludingTax,
      subtotalIncludingTax: editForm.subtotalIncludingTax,
    });
  };

  const handleComplete = async () => {
    if (!batchId) return;

    await completeMutation.mutateAsync({
      batchId: parseInt(batchId),
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  // 認証不要のため、ログインチェックを削除

  const successCount = invoices?.filter((inv) => inv.status === "confirmed" || inv.status === "pending").length || 0;
  const failedCount = invoices?.filter((inv) => inv.status === "failed").length || 0;
  const reducedTaxCount = invoices?.filter((inv) => inv.hasReducedTax).length || 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="container max-w-6xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <CheckCircle className="h-6 w-6" />
              読取結果確認
            </CardTitle>
            <CardDescription>
              抽出されたデータを確認し、必要に応じて修正してください
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* サマリー */}
            <div className="grid grid-cols-3 gap-4">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">読取成功</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-green-600">{successCount}件</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">読取失敗</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-red-600">{failedCount}件</p>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm">軽減税率あり</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-2xl font-bold text-blue-600">{reducedTaxCount}件</p>
                </CardContent>
              </Card>
            </div>

            {/* テーブル */}
            <div className="border rounded-lg overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>メーカー名</TableHead>
                    <TableHead>請求書番号</TableHead>
                    <TableHead>請求日</TableHead>
                    <TableHead>税抜合計</TableHead>
                    <TableHead>税込合計</TableHead>
                    <TableHead>軽減税率</TableHead>
                    <TableHead>操作</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices?.map((invoice) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">
                        {invoice.manufacturerName || "不明"}
                      </TableCell>
                      <TableCell>{invoice.invoiceNumber || "-"}</TableCell>
                      <TableCell>
                        {invoice.invoiceDate
                          ? new Date(invoice.invoiceDate).toLocaleDateString("ja-JP")
                          : "-"}
                      </TableCell>
                      <TableCell>¥{invoice.subtotalExcludingTax.toLocaleString()}</TableCell>
                      <TableCell>¥{invoice.subtotalIncludingTax.toLocaleString()}</TableCell>
                      <TableCell>
                        <Badge variant={invoice.hasReducedTax ? "default" : "secondary"}>
                          {invoice.hasReducedTax ? "あり" : "なし"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(invoice)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>

            {/* アクションボタン */}
            <div className="flex gap-3 justify-end">
              <Button
                variant="outline"
                onClick={() => setLocation("/upload")}
              >
                戻る
              </Button>
              <Button
                onClick={handleComplete}
                disabled={completeMutation.isPending}
              >
                {completeMutation.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    生成中...
                  </>
                ) : (
                  <>
                    <Download className="mr-2 h-4 w-4" />
                    Excel生成
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* 編集ダイアログ */}
      <Dialog open={editingInvoice !== null} onOpenChange={() => setEditingInvoice(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>請求書データ編集</DialogTitle>
            <DialogDescription>
              必要な項目を修正してください
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="manufacturerName">メーカー名</Label>
              <Input
                id="manufacturerName"
                value={editForm.manufacturerName}
                onChange={(e) =>
                  setEditForm({ ...editForm, manufacturerName: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="invoiceNumber">請求書番号</Label>
              <Input
                id="invoiceNumber"
                value={editForm.invoiceNumber}
                onChange={(e) =>
                  setEditForm({ ...editForm, invoiceNumber: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="invoiceDate">請求日</Label>
              <Input
                id="invoiceDate"
                type="date"
                value={editForm.invoiceDate}
                onChange={(e) =>
                  setEditForm({ ...editForm, invoiceDate: e.target.value })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="subtotalExcludingTax">税抜合計</Label>
              <Input
                id="subtotalExcludingTax"
                type="number"
                value={editForm.subtotalExcludingTax}
                onChange={(e) =>
                  setEditForm({
                    ...editForm,
                    subtotalExcludingTax: parseInt(e.target.value),
                  })
                }
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="subtotalIncludingTax">税込合計</Label>
              <Input
                id="subtotalIncludingTax"
                type="number"
                value={editForm.subtotalIncludingTax}
                onChange={(e) =>
                  setEditForm({
                    ...editForm,
                    subtotalIncludingTax: parseInt(e.target.value),
                  })
                }
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingInvoice(null)}>
              キャンセル
            </Button>
            <Button onClick={handleSave} disabled={updateMutation.isPending}>
              {updateMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  保存中...
                </>
              ) : (
                "保存"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
