// import { useAuth } from "@/_core/hooks/useAuth"; // 認証不要のためコメントアウト
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, Download, FileText } from "lucide-react";
import { useLocation } from "wouter";

export default function History() {
  // const { user, loading: authLoading } = useAuth(); // 認証不要のためコメントアウト
  const [, setLocation] = useLocation();

  const { data: batches, isLoading } = trpc.invoices.listBatches.useQuery();

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  // 認証不要のため、ログインチェックを削除

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12 px-4">
      <div className="container max-w-6xl">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl flex items-center gap-2">
              <FileText className="h-6 w-6" />
              処理履歴
            </CardTitle>
            <CardDescription>
              過去の請求書処理履歴とExcelファイルのダウンロード
            </CardDescription>
          </CardHeader>
          <CardContent>
            {batches && batches.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">まだ処理履歴がありません</p>
                <Button onClick={() => setLocation("/upload")}>
                  請求書をアップロード
                </Button>
              </div>
            ) : (
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>年月</TableHead>
                      <TableHead>ファイル数</TableHead>
                      <TableHead>成功</TableHead>
                      <TableHead>失敗</TableHead>
                      <TableHead>ステータス</TableHead>
                      <TableHead>作成日時</TableHead>
                      <TableHead>操作</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {batches?.map((batch) => (
                      <TableRow key={batch.id}>
                        <TableCell className="font-medium">
                          {batch.year}年{batch.month}月
                        </TableCell>
                        <TableCell>{batch.totalFiles}</TableCell>
                        <TableCell className="text-green-600">
                          {batch.successCount}
                        </TableCell>
                        <TableCell className="text-red-600">
                          {batch.failedCount}
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant={
                              batch.status === "completed"
                                ? "default"
                                : batch.status === "failed"
                                ? "destructive"
                                : "secondary"
                            }
                          >
                            {batch.status === "completed"
                              ? "完了"
                              : batch.status === "failed"
                              ? "失敗"
                              : "処理中"}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          {new Date(batch.createdAt).toLocaleString("ja-JP")}
                        </TableCell>
                        <TableCell>
                          {batch.status === "completed" && batch.excelFileUrl && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => window.open(batch.excelFileUrl!, "_blank")}
                            >
                              <Download className="h-4 w-4 mr-2" />
                              ダウンロード
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
