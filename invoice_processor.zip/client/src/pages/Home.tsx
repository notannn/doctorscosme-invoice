import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText, CheckCircle, Download, TrendingUp, Shield, Zap } from "lucide-react";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";

export default function Home() {
  const { user, loading } = useAuth();
  const [, setLocation] = useLocation();

  const handleGetStarted = () => {
    if (user) {
      setLocation("/upload");
    } else {
      window.location.href = getLoginUrl();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* ヘッダー */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="h-6 w-6 text-blue-600" />
            <h1 className="text-xl font-bold">請求書自動処理アシスタント</h1>
          </div>
          <div className="flex items-center gap-4">
            {user ? (
              <>
                <Button variant="ghost" onClick={() => setLocation("/history")}>
                  処理履歴
                </Button>
                <Button onClick={() => setLocation("/upload")}>
                  アップロード
                </Button>
              </>
            ) : (
              <Button onClick={() => (window.location.href = getLoginUrl())}>
                ログイン
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* ヒーローセクション */}
      <section className="py-20 px-4">
        <div className="container max-w-4xl text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-100 text-blue-700 text-sm font-medium mb-6">
            <Shield className="h-4 w-4" />
            ハルシネーション防止機能搭載
          </div>
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            請求書処理を自動化し、<br />業務効率を劇的に向上
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            PDFや画像の請求書から自動でデータを抽出し、毎月同一フォーマットのExcel集計表を生成。
            法人番号優先のメーカー判定で、正確性を確保します。
          </p>
          <div className="flex gap-4 justify-center">
            <Button size="lg" onClick={handleGetStarted}>
              今すぐ始める
            </Button>
            <Button size="lg" variant="outline" onClick={() => setLocation("/history")}>
              処理履歴を見る
            </Button>
          </div>
        </div>
      </section>

      {/* 特徴セクション */}
      <section className="py-16 px-4 bg-white">
        <div className="container max-w-6xl">
          <h3 className="text-3xl font-bold text-center mb-12">主な機能</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-blue-100 flex items-center justify-center mb-4">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <CardTitle>自動データ抽出</CardTitle>
                <CardDescription>
                  PDF・画像から請求書情報を自動抽出。OCR技術とLLMを組み合わせて高精度な読み取りを実現。
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-green-100 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-green-600" />
                </div>
                <CardTitle>メーカー自動判定</CardTitle>
                <CardDescription>
                  法人番号優先の厳密な判定ロジックで、メーカーを正確に識別。曖昧な場合はユーザー確認を促します。
                </CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-purple-100 flex items-center justify-center mb-4">
                  <Download className="h-6 w-6 text-purple-600" />
                </div>
                <CardTitle>Excel自動生成</CardTitle>
                <CardDescription>
                  数式を保持した固定フォーマットのExcelを自動生成。軽減税率にも対応し、税率別に行を分割。
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* メリットセクション */}
      <section className="py-16 px-4">
        <div className="container max-w-6xl">
          <h3 className="text-3xl font-bold text-center mb-12">導入メリット</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                    <Zap className="h-5 w-5 text-blue-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">作業時間を大幅削減</h4>
                    <p className="text-muted-foreground">
                      手動入力が不要になり、月次処理の時間を80%以上削減。複数の請求書を一括処理できます。
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                    <Shield className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">高精度なデータ抽出</h4>
                    <p className="text-muted-foreground">
                      ルールベースの判定ロジックとLLMを組み合わせ、ハルシネーションを防止。確認フローで最終チェックも可能。
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                    <TrendingUp className="h-5 w-5 text-purple-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">一貫性のある出力</h4>
                    <p className="text-muted-foreground">
                      毎月同じフォーマットのExcelを生成。数式も保持されるため、後から計算式を確認・修正できます。
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-start gap-4">
                  <div className="h-10 w-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                    <CheckCircle className="h-5 w-5 text-orange-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold mb-2">軽減税率対応</h4>
                    <p className="text-muted-foreground">
                      10%と8%の混在する請求書も自動判定。税率別に行を分割して正確な集計を実現します。
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTAセクション */}
      <section className="py-20 px-4 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="container max-w-4xl text-center">
          <h3 className="text-3xl md:text-4xl font-bold mb-6">
            今すぐ請求書処理を自動化
          </h3>
          <p className="text-xl mb-8 opacity-90">
            無料で始められます。アカウント登録後、すぐにご利用いただけます。
          </p>
          <Button size="lg" variant="secondary" onClick={handleGetStarted}>
            無料で始める
          </Button>
        </div>
      </section>

      {/* フッター */}
      <footer className="py-8 px-4 border-t bg-white">
        <div className="container text-center text-muted-foreground">
          <p>© 2025 請求書自動処理アシスタント. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
