import { drizzle } from "drizzle-orm/mysql2";
import { manufacturers } from "../drizzle/schema.js";
import dotenv from "dotenv";

dotenv.config();

const db = drizzle(process.env.DATABASE_URL);

const manufacturersData = [
  {
    name: "ゼオスキン",
    corporateNumber: "T8010403029561",
    aliases: JSON.stringify(["ZO Skin Health合同会社", "ゼオスキン", "ZO SKIN HEALTH", "ZO", "Zeo"]),
  },
  {
    name: "サンソリット",
    corporateNumber: "T6011001050077",
    aliases: JSON.stringify(["株式会社サンソリット", "SUNSORIT", "Sunsorit"]),
  },
  {
    name: "ワカサプリ",
    corporateNumber: "T8010401048266",
    aliases: JSON.stringify(["株式会社分子生理化学研究所", "WAKASAPURI", "Wakasapuri", "ワカサプリ"]),
  },
  {
    name: "ジェイメック",
    corporateNumber: "T9011101055515",
    aliases: JSON.stringify(["株式会社ジェイメック", "JMEC", "Jmec"]),
  },
  {
    name: "Crystal Tomato",
    corporateNumber: null,
    aliases: JSON.stringify(["Eye-Lens Pte Ltd.", "クリスタルトマト", "Crystal Tomato", "CrystalTomato"]),
  },
];

async function seed() {
  console.log("🌱 Seeding manufacturers...");
  
  for (const manufacturer of manufacturersData) {
    try {
      await db.insert(manufacturers).values(manufacturer);
      console.log(`✅ Inserted: ${manufacturer.name}`);
    } catch (error) {
      console.error(`❌ Failed to insert ${manufacturer.name}:`, error.message);
    }
  }
  
  console.log("✨ Seeding completed!");
  process.exit(0);
}

seed().catch((error) => {
  console.error("❌ Seeding failed:", error);
  process.exit(1);
});
