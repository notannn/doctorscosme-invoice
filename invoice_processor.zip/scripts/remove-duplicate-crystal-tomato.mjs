import { drizzle } from "drizzle-orm/mysql2";
import { manufacturers } from "../drizzle/schema.ts";
import { eq } from "drizzle-orm";
import dotenv from "dotenv";

dotenv.config();

const db = drizzle(process.env.DATABASE_URL);

async function removeDuplicate() {
  // Crystal Tomatoのレコードを全て取得
  const crystalTomatoes = await db
    .select()
    .from(manufacturers)
    .where(eq(manufacturers.name, "Crystal Tomato"));

  console.log(`Found ${crystalTomatoes.length} Crystal Tomato records`);
  
  if (crystalTomatoes.length > 1) {
    // IDが最小のものを残し、それ以外を削除
    const minId = Math.min(...crystalTomatoes.map(m => m.id));
    const toDelete = crystalTomatoes.filter(m => m.id !== minId);
    
    for (const record of toDelete) {
      console.log(`Deleting duplicate: ID=${record.id}, Name=${record.name}`);
      await db.delete(manufacturers).where(eq(manufacturers.id, record.id));
    }
    
    console.log(`Deleted ${toDelete.length} duplicate record(s)`);
  } else {
    console.log("No duplicates found");
  }
  
  // 削除後の確認
  const remaining = await db
    .select()
    .from(manufacturers)
    .where(eq(manufacturers.name, "Crystal Tomato"));
  console.log(`Remaining Crystal Tomato records: ${remaining.length}`);
}

removeDuplicate().then(() => process.exit(0)).catch(console.error);
