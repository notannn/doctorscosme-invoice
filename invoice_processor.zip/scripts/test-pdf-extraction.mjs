import { extractInvoiceData } from "../server/invoiceExtractor.ts";
import { matchManufacturer, detectTaxRates } from "../server/manufacturerMatcher.ts";
import { getAllManufacturers } from "../server/db.ts";
import fs from "fs";
import path from "path";

async function testPdfExtraction() {
  console.log("=== 請求書PDF抽出テスト開始 ===\n");

  // テスト用PDFファイル
  const testFiles = [
    "/home/ubuntu/upload/Invoice_INV226463_1762347741955.pdf",
    "/home/ubuntu/upload/請求明細書_013324_2025年11月30日.pdf",
    "/home/ubuntu/upload/20251203__6E9V-WV3Y.pdf",
  ];

  // メーカーマスターデータを取得
  const manufacturers = await getAllManufacturers();
  console.log(`メーカーマスター: ${manufacturers.length}件\n`);

  for (const filePath of testFiles) {
    if (!fs.existsSync(filePath)) {
      console.log(`⚠️  ファイルが見つかりません: ${filePath}\n`);
      continue;
    }

    console.log(`📄 テストファイル: ${path.basename(filePath)}`);
    console.log("─".repeat(60));

    try {
      // ファイルをBase64エンコード
      const fileBuffer = fs.readFileSync(filePath);
      const base64 = fileBuffer.toString("base64");
      const dataUrl = `data:application/pdf;base64,${base64}`;

      // データ抽出
      const extracted = await extractInvoiceData(dataUrl, "application/pdf");

      console.log("✅ データ抽出成功:");
      console.log(`  請求書番号: ${extracted.invoiceNumber || "不明"}`);
      console.log(`  請求日: ${extracted.invoiceDate ? extracted.invoiceDate.toISOString().split("T")[0] : "不明"}`);
      console.log(`  税抜合計: ¥${extracted.subtotalExcludingTax.toLocaleString()}`);
      console.log(`  税込合計: ¥${extracted.subtotalIncludingTax.toLocaleString()}`);

      // メーカー判定
      const manufacturerMatch = matchManufacturer(extracted.extractedText, manufacturers);
      console.log(`\n  メーカー判定: ${manufacturerMatch.manufacturer?.name || "不明"}`);
      console.log(`  信頼度: ${manufacturerMatch.confidence}`);
      console.log(`  判定方法: ${manufacturerMatch.matchedBy}`);

      // 税率判定
      const taxRates = detectTaxRates(extracted.extractedText);
      console.log(`\n  軽減税率あり: ${taxRates.hasReducedTax ? "Yes" : "No"}`);
      console.log(`  税率: ${taxRates.rates.map((r) => r.rate).join(", ")}`);

      // 税率別内訳を表示
      if (extracted.taxRateBreakdowns && extracted.taxRateBreakdowns.length > 0) {
        console.log(`\n  税率別内訳:`);
        for (const breakdown of extracted.taxRateBreakdowns) {
          console.log(`    ${breakdown.taxRate === "0.10" ? "10%" : "8%"}税率:`);
          console.log(`      税抜: ¥${breakdown.subtotalExcludingTax.toLocaleString()}`);
          console.log(`      税込: ¥${breakdown.subtotalIncludingTax.toLocaleString()}`);
        }
      } else {
        console.log(`\n  ⚠️  税率別内訳なし（LLMが抽出できませんでした）`);
      }

      console.log("\n");
    } catch (error) {
      console.error(`❌ エラー: ${error instanceof Error ? error.message : String(error)}\n`);
    }
  }

  console.log("=== テスト完了 ===");
}

testPdfExtraction().catch(console.error);
