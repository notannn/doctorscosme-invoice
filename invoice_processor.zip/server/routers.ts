import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  getAllManufacturers,
  updateManufacturerMarginRate,
  createManufacturer,
  updateManufacturer,
  deleteManufacturer,
  createInvoiceBatch,
  getInvoiceBatchById,
  updateInvoiceBatch,
  getUserInvoiceBatches,
  createInvoice,
  getInvoicesByBatchId,
  updateInvoice,
} from "./db";
import { storagePut } from "./storage";
import { extractInvoiceData } from "./invoiceExtractor";
import { matchManufacturer, detectTaxRates } from "./manufacturerMatcher";
import { generateExcel, generateExcelFileName } from "./excelGenerator";
import { nanoid } from "nanoid";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  manufacturers: router({
    list: publicProcedure.query(async () => {
      return await getAllManufacturers();
    }),
    updateMarginRate: publicProcedure
      .input(
        z.object({
          id: z.number(),
          marginRate: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        await updateManufacturerMarginRate(input.id, input.marginRate);
        return { success: true };
      }),
    create: publicProcedure
      .input(
        z.object({
          name: z.string(),
          corporateNumber: z.string().nullable(),
          aliases: z.array(z.string()),
          marginRate: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const id = await createManufacturer({
          name: input.name,
          corporateNumber: input.corporateNumber,
          aliases: JSON.stringify(input.aliases),
          marginRate: input.marginRate || "5.00",
        });
        return { success: true, id };
      }),
    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          name: z.string().optional(),
          corporateNumber: z.string().nullable().optional(),
          aliases: z.array(z.string()).optional(),
          marginRate: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        const updateData: Record<string, any> = {};
        
        if (data.name !== undefined) updateData.name = data.name;
        if (data.corporateNumber !== undefined) updateData.corporateNumber = data.corporateNumber;
        if (data.aliases !== undefined) updateData.aliases = JSON.stringify(data.aliases);
        if (data.marginRate !== undefined) updateData.marginRate = data.marginRate;
        
        await updateManufacturer(id, updateData);
        return { success: true };
      }),
    delete: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteManufacturer(input.id);
        return { success: true };
      }),
  }),

  invoices: router({
    // バッチを作成
    createBatch: publicProcedure
      .input(
        z.object({
          year: z.number(),
          month: z.number(),
          totalFiles: z.number(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const batchId = await createInvoiceBatch({
          userId: 0, // 認証不要
          year: input.year,
          month: input.month,
          totalFiles: input.totalFiles,
          status: "processing",
          successCount: 0,
          failedCount: 0,
        });
        return { batchId };
      }),

    // ファイルをアップロードして処理
    uploadAndProcess: publicProcedure
      .input(
        z.object({
          batchId: z.number(),
          fileName: z.string(),
          fileData: z.string(), // Base64エンコードされたファイルデータ
          mimeType: z.string(),
        })
      )
      .mutation(async ({ input }) => {
        try {
          // ファイルをS3にアップロード
          const fileBuffer = Buffer.from(input.fileData, "base64");
          const fileKey = `invoices/public/${input.batchId}/${nanoid()}-${input.fileName}`;
          const { url: fileUrl } = await storagePut(fileKey, fileBuffer, input.mimeType);

          // OCR/テキスト抽出
          const extractedData = await extractInvoiceData(fileUrl, input.mimeType);

          // メーカー判定
          const manufacturers = await getAllManufacturers();
          const matchResult = matchManufacturer(extractedData.extractedText, manufacturers);

          // 税率判定
          const taxRateResult = detectTaxRates(extractedData.extractedText);

          // 請求書データを保存
          const invoiceId = await createInvoice({
            batchId: input.batchId,
            manufacturerId: matchResult.manufacturer?.id || null,
            manufacturerName: matchResult.manufacturer?.name || null,
            invoiceNumber: extractedData.invoiceNumber,
            invoiceDate: extractedData.invoiceDate,
            hasReducedTax: taxRateResult.hasReducedTax,
            subtotalExcludingTax: extractedData.subtotalExcludingTax,
            subtotalIncludingTax: extractedData.subtotalIncludingTax,
            taxRate: taxRateResult.rates[0]?.rate || "0.10",
            taxRateBreakdowns: JSON.stringify(extractedData.taxRateBreakdowns), // JSON形式で保存
            originalFileKey: fileKey,
            originalFileUrl: fileUrl,
            originalFileName: input.fileName,
            extractedText: extractedData.extractedText,
            status: "pending",
          });

          // バッチの成功カウントを更新
          const batch = await getInvoiceBatchById(input.batchId);
          if (batch) {
            await updateInvoiceBatch(input.batchId, {
              successCount: batch.successCount + 1,
            });
          }

          return {
            invoiceId,
            manufacturerName: matchResult.manufacturer?.name || "不明",
            confidence: matchResult.confidence,
            matchedBy: matchResult.matchedBy,
            hasReducedTax: taxRateResult.hasReducedTax,
            taxRateBreakdowns: extractedData.taxRateBreakdowns,
          };
        } catch (error) {
          // バッチの失敗カウントを更新
          const batch = await getInvoiceBatchById(input.batchId);
          if (batch) {
            await updateInvoiceBatch(input.batchId, {
              failedCount: batch.failedCount + 1,
            });
          }

          throw error;
        }
      }),

    // バッチの請求書一覧を取得
    listByBatch: publicProcedure
      .input(z.object({ batchId: z.number() }))
      .query(async ({ input }) => {
        return await getInvoicesByBatchId(input.batchId);
      }),

    // 請求書データを更新
    update: publicProcedure
      .input(
        z.object({
          id: z.number(),
          manufacturerId: z.number().optional(),
          manufacturerName: z.string().optional(),
          invoiceNumber: z.string().optional(),
          invoiceDate: z.date().optional(),
          subtotalExcludingTax: z.number().optional(),
          subtotalIncludingTax: z.number().optional(),
          taxRate: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...updates } = input;
        await updateInvoice(id, updates);
        return { success: true };
      }),

    // バッチを完了してExcelを生成
    completeBatch: publicProcedure
      .input(z.object({ batchId: z.number() }))
      .mutation(async ({ input }) => {
        const batch = await getInvoiceBatchById(input.batchId);
        if (!batch) {
          throw new Error("Batch not found");
        }

        const invoices = await getInvoicesByBatchId(input.batchId);

        // Excelを生成
        const excelBuffer = await generateExcel(invoices, batch.year, batch.month);
        const fileName = generateExcelFileName(batch.year, batch.month);
        const fileKey = `excel/${batch.userId}/${input.batchId}/${fileName}`;

        // S3にアップロード
        const { url: excelUrl } = await storagePut(
          fileKey,
          excelBuffer,
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        );

        // バッチを完了状態に更新
        await updateInvoiceBatch(input.batchId, {
          status: "completed",
          excelFileKey: fileKey,
          excelFileUrl: excelUrl,
        });

        return {
          excelUrl,
          fileName,
        };
      }),

    // 全てのバッチ一覧を取得（認証不要）
    listBatches: publicProcedure.query(async () => {
      return await getUserInvoiceBatches(0); // 全件取得
    }),
  }),
});

export type AppRouter = typeof appRouter;
