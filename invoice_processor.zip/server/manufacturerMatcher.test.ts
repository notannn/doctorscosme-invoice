import { describe, expect, it } from "vitest";
import {
  extractCorporateNumber,
  matchManufacturer,
  detectTaxRates,
} from "./manufacturerMatcher";
import { Manufacturer } from "../drizzle/schema";

describe("extractCorporateNumber", () => {
  it("should extract corporate number from text", () => {
    const text = "法人番号: T8010403029561";
    const result = extractCorporateNumber(text);
    expect(result).toBe("T8010403029561");
  });

  it("should return null if no corporate number found", () => {
    const text = "これは法人番号を含まないテキストです";
    const result = extractCorporateNumber(text);
    expect(result).toBeNull();
  });
});

describe("matchManufacturer", () => {
  const manufacturers: Manufacturer[] = [
    {
      id: 1,
      name: "ゼオスキン",
      corporateNumber: "T8010403029561",
      aliases: JSON.stringify(["ZO Skin Health合同会社", "ZO SKIN HEALTH"]),
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      id: 2,
      name: "サンソリット",
      corporateNumber: "T6011001050077",
      aliases: JSON.stringify(["株式会社サンソリット", "SUNSORIT"]),
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ];

  it("should match by corporate number with high confidence", () => {
    const text = "請求書\n法人番号: T8010403029561\nZO Skin Health合同会社";
    const result = matchManufacturer(text, manufacturers);

    expect(result.manufacturer?.name).toBe("ゼオスキン");
    expect(result.confidence).toBe("high");
    expect(result.matchedBy).toBe("corporateNumber");
  });

  it("should match by company name with medium confidence", () => {
    const text = "請求書\nゼオスキン\n合計金額: 100,000円";
    const result = matchManufacturer(text, manufacturers);

    expect(result.manufacturer?.name).toBe("ゼオスキン");
    expect(result.confidence).toBe("medium");
    expect(result.matchedBy).toBe("name");
  });

  it("should match by alias with medium confidence", () => {
    const text = "請求書\nZO SKIN HEALTH\n合計金額: 100,000円";
    const result = matchManufacturer(text, manufacturers);

    expect(result.manufacturer?.name).toBe("ゼオスキン");
    expect(result.confidence).toBe("medium");
    expect(result.matchedBy).toBe("alias");
  });

  it("should return none if no match found", () => {
    const text = "請求書\n不明なメーカー\n合計金額: 100,000円";
    const result = matchManufacturer(text, manufacturers);

    expect(result.manufacturer).toBeNull();
    expect(result.confidence).toBe("none");
    expect(result.matchedBy).toBe("none");
  });
});

describe("detectTaxRates", () => {
  it("should detect both 10% and 8% tax rates", () => {
    const text = "消費税10%: 5,000円\n軽減税率8%: 2,000円";
    const result = detectTaxRates(text);

    expect(result.hasReducedTax).toBe(true);
    expect(result.rates).toHaveLength(2);
    expect(result.rates[0]?.rate).toBe("0.10");
    expect(result.rates[1]?.rate).toBe("0.08");
  });

  it("should detect only 8% tax rate", () => {
    const text = "軽減税率8%: 2,000円";
    const result = detectTaxRates(text);

    expect(result.hasReducedTax).toBe(true);
    expect(result.rates).toHaveLength(1);
    expect(result.rates[0]?.rate).toBe("0.08");
  });

  it("should default to 10% if no specific rate mentioned", () => {
    const text = "合計金額: 100,000円";
    const result = detectTaxRates(text);

    expect(result.hasReducedTax).toBe(false);
    expect(result.rates).toHaveLength(1);
    expect(result.rates[0]?.rate).toBe("0.10");
  });
});
