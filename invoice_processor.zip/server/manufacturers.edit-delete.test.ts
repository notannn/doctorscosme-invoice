import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";
import { createManufacturer, deleteManufacturer } from "./db";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("manufacturers.update", () => {
  it("メーカー情報を更新できる", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // テストメーカーを作成
    const id = await createManufacturer({
      name: "更新テストメーカー",
      corporateNumber: "T1111111111111",
      aliases: JSON.stringify(["Test"]),
      marginRate: "5.00",
    });

    // 更新
    const result = await caller.manufacturers.update({
      id,
      name: "更新後メーカー",
      corporateNumber: "T2222222222222",
      aliases: ["Updated Test", "テスト更新"],
      marginRate: "7.50",
    });

    expect(result.success).toBe(true);

    // 更新されたメーカーを取得して確認
    const manufacturers = await caller.manufacturers.list();
    const updated = manufacturers.find((m) => m.id === id);
    expect(updated?.name).toBe("更新後メーカー");
    expect(updated?.corporateNumber).toBe("T2222222222222");
    expect(updated?.marginRate).toBe("7.50");

    // クリーンアップ
    await deleteManufacturer(id);
  });

  it("一部のフィールドのみ更新できる", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // テストメーカーを作成
    const id = await createManufacturer({
      name: "部分更新テストメーカー",
      corporateNumber: "T3333333333333",
      aliases: JSON.stringify(["Partial"]),
      marginRate: "5.00",
    });

    // マージン率のみ更新
    const result = await caller.manufacturers.update({
      id,
      marginRate: "10.00",
    });

    expect(result.success).toBe(true);

    // 更新されたメーカーを取得して確認
    const manufacturers = await caller.manufacturers.list();
    const updated = manufacturers.find((m) => m.id === id);
    expect(updated?.name).toBe("部分更新テストメーカー"); // 変更なし
    expect(updated?.corporateNumber).toBe("T3333333333333"); // 変更なし
    expect(updated?.marginRate).toBe("10.00"); // 更新された

    // クリーンアップ
    await deleteManufacturer(id);
  });
});

describe("manufacturers.delete", () => {
  it("メーカーを削除できる", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // テストメーカーを作成
    const id = await createManufacturer({
      name: "削除テストメーカー",
      corporateNumber: null,
      aliases: JSON.stringify(["Delete Test"]),
      marginRate: "5.00",
    });

    // 削除前に存在確認
    const beforeDelete = await caller.manufacturers.list();
    expect(beforeDelete.find((m) => m.id === id)).toBeDefined();

    // 削除
    const result = await caller.manufacturers.delete({ id });
    expect(result.success).toBe(true);

    // 削除後に存在しないことを確認
    const afterDelete = await caller.manufacturers.list();
    expect(afterDelete.find((m) => m.id === id)).toBeUndefined();
  });
});
