import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "sample-user",
    email: "sample@example.com",
    name: "Sample User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("manufacturers.updateMarginRate", () => {
  it("メーカーのマージン率を更新できる", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    // メーカー一覧を取得
    const manufacturers = await caller.manufacturers.list();
    expect(manufacturers.length).toBeGreaterThan(0);

    const firstManufacturer = manufacturers[0];
    if (!firstManufacturer) {
      throw new Error("No manufacturers found");
    }

    // マージン率を更新
    const result = await caller.manufacturers.updateMarginRate({
      id: firstManufacturer.id,
      marginRate: "7.50",
    });

    expect(result).toEqual({ success: true });

    // 更新後のメーカー一覧を取得して確認
    const updatedManufacturers = await caller.manufacturers.list();
    const updatedManufacturer = updatedManufacturers.find(
      (m) => m.id === firstManufacturer.id
    );

    expect(updatedManufacturer?.marginRate).toBe("7.50");
  });

  it("デフォルトのマージン率は5%である", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const manufacturers = await caller.manufacturers.list();
    
    // 全メーカーのマージン率を確認（初期値は5.00のはず）
    manufacturers.forEach((manufacturer) => {
      expect(manufacturer.marginRate).toBeDefined();
      // 数値として5.00であることを確認（文字列の場合もあるため）
      const rate = parseFloat(manufacturer.marginRate || "0");
      expect(rate).toBeGreaterThanOrEqual(0);
    });
  });
});
