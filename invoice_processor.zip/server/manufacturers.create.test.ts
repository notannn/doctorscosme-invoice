import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("manufacturers.create", () => {
  it("新規メーカーを作成できる", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.manufacturers.create({
      name: "テストメーカー",
      corporateNumber: "T1234567890123",
      aliases: ["Test Manufacturer", "テスト"],
      marginRate: "7.50",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBeTypeOf("number");
  });

  it("法人番号なしでメーカーを作成できる", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.manufacturers.create({
      name: "法人番号なしメーカー",
      corporateNumber: null,
      aliases: ["No Corporate Number"],
      marginRate: "5.00",
    });

    expect(result.success).toBe(true);
    expect(result.id).toBeTypeOf("number");
  });

  it("マージン率を指定しない場合はデフォルト5.00%が設定される", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.manufacturers.create({
      name: "デフォルトマージン率メーカー",
      corporateNumber: null,
      aliases: ["Default Margin"],
    });

    expect(result.success).toBe(true);
    
    // 作成されたメーカーを取得して確認
    const manufacturers = await caller.manufacturers.list();
    const created = manufacturers.find(m => m.id === result.id);
    expect(created?.marginRate).toBe("5.00");
  });
});
