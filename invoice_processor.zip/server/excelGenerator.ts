import ExcelJS from "exceljs";
import { Invoice, Manufacturer } from "../drizzle/schema";
import { getManufacturerById } from "./db";

/**
 * Excel生成用の請求書データ行
 */
export interface ExcelInvoiceRow {
  manufacturerName: string;
  invoiceNumber: string;
  hasReducedTax: string; // "Yes" or "No"
  invoiceDate: string;
  subtotalExcludingTax: number;
  subtotalIncludingTax: number;
  taxRate: string; // "0.10" or "0.08"
  marginRate: number; // マージン率（%）
}

/**
 * 税率別内訳
 */
interface TaxRateBreakdown {
  taxRate: string;
  subtotalExcludingTax: number;
  subtotalIncludingTax: number;
}

/**
 * 請求書データからExcelファイルを生成
 * 数式を保持した形式で出力
 */
export async function generateExcel(
  invoices: Invoice[],
  year: number,
  month: number
): Promise<Buffer> {
  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("請求書集計");

  // ヘッダー行を追加（太字）
  const headerRow = worksheet.addRow([
    "メーカー名",
    "請求書番号",
    "軽減税率あり?",
    "請求日",
    "請求書記載合計（税抜）",
    "請求書記載合計（税込）",
    "仕入原価",
    "売上原価",
    "粗利（税抜）",
    "粗利（税込）",
    "税率",
  ]);

  // ヘッダーを太字に
  headerRow.font = { bold: true };

  // 各請求書のデータを行として追加
  const rows: ExcelInvoiceRow[] = [];

  for (const invoice of invoices) {
    // メーカー情報を取得してマージン率を取得
    let marginRate = 5.0; // デフォルト5%
    if (invoice.manufacturerId) {
      const manufacturer = await getManufacturerById(invoice.manufacturerId);
      if (manufacturer && manufacturer.marginRate) {
        marginRate = parseFloat(manufacturer.marginRate);
      }
    }

    // taxRateBreakdownsがある場合はそれを使用
    let breakdowns: TaxRateBreakdown[] = [];
    
    if (invoice.taxRateBreakdowns) {
      try {
        breakdowns = JSON.parse(invoice.taxRateBreakdowns);
      } catch (error) {
        console.error("Failed to parse taxRateBreakdowns:", error);
      }
    }

    // 税率別内訳がある場合は、それぞれの税率で行を作成
    if (breakdowns.length > 0) {
      for (const breakdown of breakdowns) {
        rows.push({
          manufacturerName: invoice.manufacturerName || "不明",
          invoiceNumber: invoice.invoiceNumber || "",
          hasReducedTax: invoice.hasReducedTax ? "Yes" : "No",
          invoiceDate: invoice.invoiceDate
            ? invoice.invoiceDate.toISOString().split("T")[0]
            : "",
          subtotalExcludingTax: breakdown.subtotalExcludingTax,
          subtotalIncludingTax: breakdown.subtotalIncludingTax,
          taxRate: breakdown.taxRate,
          marginRate,
        });
      }
    } else {
      // 税率別内訳がない場合は、従来通り1行で出力
      rows.push({
        manufacturerName: invoice.manufacturerName || "不明",
        invoiceNumber: invoice.invoiceNumber || "",
        hasReducedTax: invoice.hasReducedTax ? "Yes" : "No",
        invoiceDate: invoice.invoiceDate
          ? invoice.invoiceDate.toISOString().split("T")[0]
          : "",
        subtotalExcludingTax: invoice.subtotalExcludingTax,
        subtotalIncludingTax: invoice.subtotalIncludingTax,
        taxRate: invoice.taxRate || "0.10",
        marginRate,
      });
    }
  }

  // データ行を追加（数式を含む）
  rows.forEach((row, index) => {
    const rowNumber = index + 2; // ヘッダーが1行目なので2から始まる
    
    // マージン率を小数に変換（例: 5% → 0.05）
    const marginRateDecimal = row.marginRate / 100;

    const dataRow = worksheet.addRow([
      row.manufacturerName, // A列
      row.invoiceNumber, // B列
      row.hasReducedTax, // C列
      row.invoiceDate, // D列
      row.subtotalExcludingTax, // E列
      row.subtotalIncludingTax, // F列
      { formula: `ROUNDUP(E${rowNumber}*(1+${marginRateDecimal}),0)` }, // G列: 仕入原価 = 税抜 × (1 + マージン率)
      { formula: `ROUNDUP(G${rowNumber}*(1+K${rowNumber}),0)` }, // H列: 売上原価 = 仕入原価 × (1 + 税率)
      { formula: `G${rowNumber}-E${rowNumber}` }, // I列: 粗利（税抜）= 仕入原価 - 税抜
      { formula: `I${rowNumber}*(1+K${rowNumber})` }, // J列: 粗利（税込）= 粗利（税抜）× (1 + 税率)
      parseFloat(row.taxRate), // K列: 税率（数値）
    ]);
  });

  // 列幅を自動調整
  worksheet.columns.forEach((column) => {
    if (column) {
      column.width = 20;
    }
  });

  // Bufferとして出力
  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

/**
 * ファイル名を生成
 * 例: "2025年1月 請求書マージン集計.xlsx"
 */
export function generateExcelFileName(year: number, month: number): string {
  return `${year}年${month}月 請求書マージン集計.xlsx`;
}
