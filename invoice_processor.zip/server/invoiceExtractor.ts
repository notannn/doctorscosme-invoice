import { invokeLLM } from "./_core/llm";

/**
 * 税率別の明細情報
 */
export interface TaxRateBreakdown {
  taxRate: string; // "0.10" or "0.08"
  subtotalExcludingTax: number;
  subtotalIncludingTax: number;
}

/**
 * 請求書から抽出されたデータ
 */
export interface ExtractedInvoiceData {
  invoiceNumber: string | null;
  invoiceDate: Date | null;
  subtotalExcludingTax: number;
  subtotalIncludingTax: number;
  extractedText: string;
  taxRateBreakdowns: TaxRateBreakdown[];
}

/**
 * LLMを使用して請求書画像/PDFからデータを抽出
 */
export async function extractInvoiceData(
  fileUrl: string,
  mimeType: string
): Promise<ExtractedInvoiceData> {
  const isImage = mimeType.startsWith("image/");
  const isPdf = mimeType === "application/pdf";

  if (!isImage && !isPdf) {
    throw new Error(`Unsupported file type: ${mimeType}`);
  }

  // LLMに構造化されたJSONを返すように指示
  const systemPrompt = `あなたは日本の請求書データ抽出の専門家です。
提供された請求書画像またはPDFから、以下の情報を正確に抽出してください。

抽出する情報:
1. 請求書番号（invoiceNumber）- 「請求番号」「INV」などの記載
2. 請求日（invoiceDate）- 「請求年月日」「請求日」などの日付
3. 税抜合計金額（subtotalExcludingTax）- 税抜の合計金額
4. 税込合計金額（subtotalIncludingTax）- 税込の合計金額（「ご請求金額」「税込合計金額」など）
5. 税率別内訳（taxRateBreakdowns）- 10%と8%の商品を分けて集計
6. 抽出されたテキスト全文（extractedText）

税率判定の重要ルール:
- サンソリット（株式会社サンソリット）の請求書:
  * 明細の「区分」列に「※」印がある商品 → 軽減税率8%
  * 「※」印がない商品 → 標準税率10%
  * 2ページ目に「8.00% 対象」「10.00% 対象」と税率別の金額が記載されている場合はそれを使用

- ワカサプリ（株式会社分子生理化学研究所）の請求書:
  * 明細の「区分」列に「※」印がある商品 → 軽減税率8%
  * 「※」印がない商品 → 標準税率10%

- その他のメーカー:
  * 「軽減税率」「8%」などの記載がある場合は8%
  * 記載がない場合は10%

重要な注意事項:
- 金額は必ず数値のみで返してください（カンマや円記号、小数点は含めない、整数のみ）
- 日付はYYYY-MM-DD形式で返してください（例: 2025-11-05）
- 情報が見つからない場合は空文字列""を返してください（nullではなく）
- 税率別内訳は、10%と8%の商品を分けて集計してください
- 税率別内訳が明確でない場合は、全額を10%として扱ってください
- 「前回請求額」「御入金額」などは無視してください`;

  const userPrompt = `この請求書から必要な情報を抽出してください。
特に以下の点に注意してください:
- 請求書番号: 「請求番号」「INV」「SO」などの記載を探す
- 請求日: 「請求年月日」の日付
- 税込合計: 「ご請求金額」「今回御請求額」「税込合計金額」などの最終金額
- 税抜合計: 税込金額から消費税を引いた金額、または「税抜合計」の記載
- 税率別内訳: 明細の「区分」列の「※」印や、税率の記載から10%と8%を分けて集計`;

  try {
    const response = await invokeLLM({
      messages: [
        { role: "system", content: systemPrompt },
        {
          role: "user",
          content: [
            { type: "text", text: userPrompt },
            {
              type: isPdf ? "file_url" : "image_url",
              [isPdf ? "file_url" : "image_url"]: {
                url: fileUrl,
                ...(isPdf ? { mime_type: "application/pdf" as const } : { detail: "high" as const }),
              },
            },
          ] as any,
        },
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "invoice_extraction",
          strict: true,
          schema: {
            type: "object",
            properties: {
              invoiceNumber: {
                type: "string",
                description: "請求書番号（INV、SOなどの番号）、見つからない場合は空文字列",
              },
              invoiceDate: {
                type: "string",
                description: "請求日（YYYY-MM-DD形式）、見つからない場合は空文字列",
              },
              subtotalExcludingTax: {
                type: "integer",
                description: "税抜合計金額（整数、カンマなし）、見つからない場合は0",
              },
              subtotalIncludingTax: {
                type: "integer",
                description: "税込合計金額（整数、カンマなし）、見つからない場合は0",
              },
              taxRateBreakdowns: {
                type: "array",
                description: "税率別の内訳（10%と8%を分けて集計）",
                items: {
                  type: "object",
                  properties: {
                    taxRate: {
                      type: "string",
                      description: "税率（0.10 or 0.08）",
                    },
                    subtotalExcludingTax: {
                      type: "integer",
                      description: "この税率での税抜金額",
                    },
                    subtotalIncludingTax: {
                      type: "integer",
                      description: "この税率での税込金額",
                    },
                  },
                  required: ["taxRate", "subtotalExcludingTax", "subtotalIncludingTax"],
                  additionalProperties: false,
                },
              },
              extractedText: {
                type: "string",
                description: "抽出されたテキスト全文",
              },
            },
            required: [
              "invoiceNumber",
              "invoiceDate",
              "subtotalExcludingTax",
              "subtotalIncludingTax",
              "taxRateBreakdowns",
              "extractedText",
            ],
            additionalProperties: false,
          },
        },
      },
    });

    if (!response || !response.choices || response.choices.length === 0) {
      console.error("[ERROR] LLM Response:", JSON.stringify(response, null, 2));
      throw new Error("LLM response is empty or invalid");
    }

    const content = response.choices[0]?.message?.content;
    if (!content) {
      throw new Error("LLM response content is empty");
    }

    const parsed = JSON.parse(typeof content === 'string' ? content : JSON.stringify(content));

    // 日付をDateオブジェクトに変換
    let invoiceDate: Date | null = null;
    if (parsed.invoiceDate && parsed.invoiceDate !== "") {
      invoiceDate = new Date(parsed.invoiceDate);
      if (isNaN(invoiceDate.getTime())) {
        invoiceDate = null;
      }
    }

    // 税率別内訳が空の場合は、全額を10%として扱う
    let taxRateBreakdowns: TaxRateBreakdown[] = parsed.taxRateBreakdowns || [];
    if (taxRateBreakdowns.length === 0 && parsed.subtotalIncludingTax > 0) {
      taxRateBreakdowns = [
        {
          taxRate: "0.10",
          subtotalExcludingTax: parsed.subtotalExcludingTax,
          subtotalIncludingTax: parsed.subtotalIncludingTax,
        },
      ];
    }

    return {
      invoiceNumber: parsed.invoiceNumber || null,
      invoiceDate,
      subtotalExcludingTax: parsed.subtotalExcludingTax || 0,
      subtotalIncludingTax: parsed.subtotalIncludingTax || 0,
      extractedText: parsed.extractedText || "",
      taxRateBreakdowns,
    };
  } catch (error) {
    console.error("Failed to extract invoice data:", error);
    throw new Error(`請求書データの抽出に失敗しました: ${error instanceof Error ? error.message : String(error)}`);
  }
}
