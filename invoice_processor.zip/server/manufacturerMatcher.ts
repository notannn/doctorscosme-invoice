import { Manufacturer } from "../drizzle/schema";

/**
 * メーカー判定結果
 */
export interface ManufacturerMatchResult {
  manufacturer: Manufacturer | null;
  confidence: "high" | "medium" | "low" | "none";
  matchedBy: "corporateNumber" | "name" | "alias" | "none";
  matchedText?: string;
}

/**
 * テキストから法人番号を抽出
 * 法人番号は13桁の数字（T + 12桁の数字）
 */
export function extractCorporateNumber(text: string): string | null {
  // T + 12桁の数字パターン
  const pattern = /T\d{12,13}/g;
  const matches = text.match(pattern);
  
  if (matches && matches.length > 0) {
    return matches[0];
  }
  
  return null;
}

/**
 * テキストを正規化（大文字小文字、全角半角、空白を統一）
 */
function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .replace(/[Ａ-Ｚａ-ｚ０-９]/g, (s) => String.fromCharCode(s.charCodeAt(0) - 0xfee0))
    .replace(/\s+/g, "");
}

/**
 * テキスト内に特定の文字列が含まれているかチェック（正規化済み）
 */
function containsNormalized(text: string, target: string): boolean {
  const normalizedText = normalizeText(text);
  const normalizedTarget = normalizeText(target);
  return normalizedText.includes(normalizedTarget);
}

/**
 * メーカーを判定する
 * 優先順位: 法人番号 > 会社名 > エイリアス
 */
export function matchManufacturer(
  extractedText: string,
  manufacturers: Manufacturer[]
): ManufacturerMatchResult {
  // 1. 法人番号で判定（最優先）
  const corporateNumber = extractCorporateNumber(extractedText);
  if (corporateNumber) {
    const matched = manufacturers.find(
      (m) => m.corporateNumber === corporateNumber
    );
    if (matched) {
      return {
        manufacturer: matched,
        confidence: "high",
        matchedBy: "corporateNumber",
        matchedText: corporateNumber,
      };
    }
  }

  // 2. 会社名で判定
  for (const manufacturer of manufacturers) {
    if (containsNormalized(extractedText, manufacturer.name)) {
      return {
        manufacturer,
        confidence: "medium",
        matchedBy: "name",
        matchedText: manufacturer.name,
      };
    }
  }

  // 3. エイリアスで判定
  for (const manufacturer of manufacturers) {
    if (manufacturer.aliases) {
      try {
        const aliases = JSON.parse(manufacturer.aliases) as string[];
        for (const alias of aliases) {
          if (containsNormalized(extractedText, alias)) {
            return {
              manufacturer,
              confidence: "medium",
              matchedBy: "alias",
              matchedText: alias,
            };
          }
        }
      } catch (error) {
        console.error(`Failed to parse aliases for ${manufacturer.name}:`, error);
      }
    }
  }

  // 判定不可
  return {
    manufacturer: null,
    confidence: "none",
    matchedBy: "none",
  };
}

/**
 * 税率を判定する
 * 軽減税率（8%）と通常税率（10%）の両方が含まれているかチェック
 */
export interface TaxRateResult {
  hasReducedTax: boolean;
  rates: Array<{ rate: string; amount: number }>;
}

export function detectTaxRates(extractedText: string): TaxRateResult {
  const text = extractedText.toLowerCase();
  
  // 8%と10%のパターンを検出
  const has8Percent = /8\s*%|8\s*％|軽減税率|軽減/.test(text);
  const has10Percent = /10\s*%|10\s*％|標準税率|消費税/.test(text);
  
  const rates: Array<{ rate: string; amount: number }> = [];
  
  // 両方含まれている場合は軽減税率あり
  if (has8Percent && has10Percent) {
    return {
      hasReducedTax: true,
      rates: [
        { rate: "0.10", amount: 0 },
        { rate: "0.08", amount: 0 },
      ],
    };
  }
  
  // 8%のみの場合
  if (has8Percent) {
    return {
      hasReducedTax: true,
      rates: [{ rate: "0.08", amount: 0 }],
    };
  }
  
  // 10%のみまたは不明の場合はデフォルトで10%
  return {
    hasReducedTax: false,
    rates: [{ rate: "0.10", amount: 0 }],
  };
}
